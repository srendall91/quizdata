UHI MSc Web Technologies
Web Application Development module
April 2019
Stuart Rendall

Assignment 2

Bootstrap Quiz App design

This is the first draft of the UI, written using 'Bootstrap' in HTML.
It is likely that some elements of the design will be adjusted/reconfigured in the working demonstration application.

All pages resize to various sceen sizes, most notably, the index page.
A 'sticky' header maintains a consistent look throughout all screens, even when scrolled.
'fluid containers' are used on some screens, but simple 'containers' may prove better in the working app.
A 'reveal answer' page has been added to the original specification.
